
package com.example.myapplicationlab7

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun TaskDetailScreen(
    task: StudyTask,
    onBackClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Task Details",
            style = MaterialTheme.typography.headlineMedium
        )

        Text(
            text = task.title,
            style = MaterialTheme.typography.titleLarge
        )

        Text(
            text = "Course: ${task.course}",
            style = MaterialTheme.typography.bodyLarge
        )

        Text(
            text = if (task.isDone) {
                "Status: Completed"
            } else {
                "Status: Not completed"
            },
            style = MaterialTheme.typography.bodyLarge
        )

        Button(onClick = onBackClick) {
            Text("Back")
        }
    }
}
