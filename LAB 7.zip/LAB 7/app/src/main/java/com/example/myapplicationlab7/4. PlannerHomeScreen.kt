
package com.example.myapplicationlab7

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Composable
fun PlannerHomeScreen(
    uiState: PlannerUiState,
    onTaskClick: (Int) -> Unit,
    onDoneChange: (Int, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Hello, ${uiState.userName}!",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "${uiState.tasks.count { it.isDone }} of " +
                    "${uiState.tasks.size} tasks done",
            style = MaterialTheme.typography.bodyLarge
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(
                items = uiState.tasks,
                key = { it.id }
            ) { task ->
                TaskItem(
                    task = task,
                    onTaskClick = onTaskClick,
                    onDoneChange = onDoneChange
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PlannerHomeScreenPreview() {
    MaterialTheme {
        PlannerHomeScreen(
            uiState = PlannerUiState(
                userName = "Student",
                tasks = listOf(
                    StudyTask(1, "Complete Lab 7", "CSC 402"),
                    StudyTask(2, "Review MIPS", "CS Course"),
                    StudyTask(3, "Study Image Processing", "ART 1407"),
                    StudyTask(4, "Prepare Dashboard", "CSC 403"),
                    StudyTask(5, "Review Lecture Notes", "CSC 402")
                )
            ),
            onTaskClick = {},
            onDoneChange = { _, _ -> }
        )
    }
}


