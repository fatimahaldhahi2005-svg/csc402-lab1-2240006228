
package com.example.myapplicationlab7

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier

@Composable
fun PlannerHomeRoute(
    onTaskClick: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var uiState by remember {
        mutableStateOf(
            PlannerUiState(
                userName = "Student",
                tasks = listOf(
                    StudyTask(
                        id = 1,
                        title = "Complete Lab 7",
                        course = "CSC 402"
                    ),
                    StudyTask(
                        id = 2,
                        title = "Review MIPS",
                        course = "CS Course"
                    ),
                    StudyTask(
                        id = 3,
                        title = "Study Image Processing",
                        course = "ART 1407"
                    ),
                    StudyTask(
                        id = 4,
                        title = "Prepare Power BI Dashboard",
                        course = "CSC 403"
                    ),
                    StudyTask(
                        id = 5,
                        title = "Review Lecture Notes",
                        course = "CSC 402"
                    )
                )
            )
        )
    }

    PlannerHomeScreen(
        uiState = uiState,
        onTaskClick = onTaskClick,
        onDoneChange = { taskId, isDone ->
            uiState = uiState.copy(
                tasks = uiState.tasks.map { task ->
                    if (task.id == taskId) {
                        task.copy(isDone = isDone)
                    } else {
                        task
                    }
                }
            )
        },
        modifier = modifier
    )
}


