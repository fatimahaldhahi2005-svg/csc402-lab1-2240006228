
package com.example.myapplicationlab7

data class PlannerUiState(
    val userName: String = "Student",
    val tasks: List<StudyTask> = emptyList()
)


