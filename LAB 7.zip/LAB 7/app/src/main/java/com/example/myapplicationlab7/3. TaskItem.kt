
package com.example.myapplicationlab7

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Composable
fun TaskItem(
    task: StudyTask,
    onTaskClick: (Int) -> Unit,
    onDoneChange: (Int, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable {
                onTaskClick(task.id)
            }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = task.isDone,
            onCheckedChange = { checked ->
                onDoneChange(task.id, checked)
            }
        )

        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = task.title,
                style = MaterialTheme.typography.titleMedium,
                textDecoration = if (task.isDone) {
                    TextDecoration.LineThrough
                } else {
                    TextDecoration.None
                }
            )

            Text(
                text = task.course,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.secondary
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun TaskItemNotDonePreview() {
    MaterialTheme {
        TaskItem(
            task = StudyTask(
                id = 1,
                title = "Complete Lab 7",
                course = "CSC 402",
                isDone = false
            ),
            onTaskClick = {},
            onDoneChange = { _, _ -> }
        )
    }
}

@Preview(showBackground = true)
@Composable
fun TaskItemDonePreview() {
    MaterialTheme {
        TaskItem(
            task = StudyTask(
                id = 2,
                title = "Review Lecture",
                course = "CSC 402",
                isDone = true
            ),
            onTaskClick = {},
            onDoneChange = { _, _ -> }
        )
    }
}
