
package com.example.myapplicationlab7

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.myapplicationlab7.ui.theme.MyApplicationLAB7Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MyApplicationLAB7Theme {
                PlannerApp()
            }
        }
    }
}

@Composable
fun PlannerApp() {
    val navController = rememberNavController()

    val tasks = listOf(
        StudyTask(1, "Complete Lab 7", "CSC 402"),
        StudyTask(2, "Review MIPS", "CS Course"),
        StudyTask(3, "Study Image Processing", "ART 1407"),
        StudyTask(4, "Prepare Power BI Dashboard", "CSC 403"),
        StudyTask(5, "Review Lecture Notes", "CSC 402")
    )

    Scaffold(
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->

        NavHost(
            navController = navController,
            startDestination = "planner",
            modifier = Modifier.padding(innerPadding)
        ) {

            composable(route = "planner") {
                PlannerHomeRoute(
                    onTaskClick = { taskId ->
                        android.util.Log.d(
                            "PlannerApp",
                            "Clicked task ID: $taskId"
                        )

                        navController.navigate("taskDetails/$taskId")
                    }
                )
            }

            composable(
                route = "taskDetails/{taskId}",
                arguments = listOf(
                    navArgument("taskId") {
                        type = NavType.IntType
                    }
                )
            ) { backStackEntry ->

                val taskId =
                    backStackEntry.arguments?.getInt("taskId")

                val selectedTask = tasks.find {
                    it.id == taskId
                }

                if (selectedTask != null) {
                    TaskDetailScreen(
                        task = selectedTask,
                        onBackClick = {
                            navController.popBackStack()
                        }
                    )
                }
            }
        }
    }
}

